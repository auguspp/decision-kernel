## Tushare Relay 补充来源

状态 PARTIAL_WITH_EXPLICIT_GAPS；市场日 2026-09-30；取得截止 2026-10-01T16:43:06.537649+00:00。第三方中转，不是官方Tushare或聪明钱评分。

| 接口 | 取得状态 | 解析行数 | 日期/身份合格行数 |
|---|---|---:|---:|
| hm_list | SUCCESS | 117 | 117 |
| hm_detail | SOURCE_ERROR | 0 | UNKNOWN |
| report_rc | PARTIAL_DAILY_PAGES | 550 | 550 |
| top_list | SUCCESS | 66 | 66 |
| top_inst | SUCCESS | 40 | 40 |

报告日分别取得；每行仍是报告的一个预测期，不是独立新事件。

| 报告日 | 状态 | 保存行数 |
|---|---|---:|
| 20261002 | SUCCESS | 0 |
| 20261001 | SUCCESS | 0 |
| 20260930 | SUCCESS | 87 |
| 20260929 | SUCCESS | 325 |
| 20260928 | SOURCE_ERROR | 0 |
| 20260927 | SUCCESS | 138 |
| 20260926 | TEMPORARY_QUEUE | 0 |

缺口：hm_detail=SOURCE_ERROR；report_rc=SOURCE_INTERPRETATION_GAP；report_rc=SOURCE_ERROR；report_rc=TEMPORARY_QUEUE；top_inst=SOURCE_INTERPRETATION_GAP

临时排队/业务 timeout 只等待30秒再试一次；仍失败留到下一自然运行。
合格只指所收单页的日期/身份解释，不代表全市场、全部分页或经济正确；空结果不是没有行为。
完整字段、来源声明、逐行缺口及原件定位见 [补充原件解释](smart-money/relay.json)。
Relay 行为与既有 HiThink/FTShare/Eastmoney/HKEX 来源并列，不静默替代。
