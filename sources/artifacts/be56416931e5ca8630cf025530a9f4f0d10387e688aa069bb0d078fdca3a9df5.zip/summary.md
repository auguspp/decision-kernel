## Tushare Relay 补充来源

状态 PARTIAL_WITH_EXPLICIT_GAPS；市场日 2026-09-29；取得截止 2026-09-29T18:10:42.699619+00:00。第三方中转，不是官方Tushare或聪明钱评分。

| 接口 | 取得状态 | 解析行数 | 日期/身份合格行数 |
|---|---|---:|---:|
| hm_list | SUCCESS | 117 | 117 |
| hm_detail | RATE_LIMIT | 0 | UNKNOWN |
| report_rc | UNAVAILABLE_DAILY_PAGES | 0 | UNKNOWN |
| top_list | NOT_ATTEMPTED_SERVICE_STOP | 0 | UNKNOWN |
| top_inst | NOT_ATTEMPTED_SERVICE_STOP | 0 | UNKNOWN |

报告日分别取得；每行仍是报告的一个预测期，不是独立新事件。

| 报告日 | 状态 | 保存行数 |
|---|---|---:|
| 20260930 | NOT_ATTEMPTED_SERVICE_STOP | 0 |
| 20260929 | NOT_ATTEMPTED_SERVICE_STOP | 0 |
| 20260928 | NOT_ATTEMPTED_SERVICE_STOP | 0 |
| 20260927 | NOT_ATTEMPTED_SERVICE_STOP | 0 |
| 20260926 | NOT_ATTEMPTED_SERVICE_STOP | 0 |
| 20260925 | NOT_ATTEMPTED_SERVICE_STOP | 0 |
| 20260924 | NOT_ATTEMPTED_SERVICE_STOP | 0 |

缺口：hm_detail=RATE_LIMIT；report_rc=NOT_ATTEMPTED_SERVICE_STOP；report_rc=NOT_ATTEMPTED_SERVICE_STOP；report_rc=NOT_ATTEMPTED_SERVICE_STOP；report_rc=NOT_ATTEMPTED_SERVICE_STOP；report_rc=NOT_ATTEMPTED_SERVICE_STOP；report_rc=NOT_ATTEMPTED_SERVICE_STOP；report_rc=NOT_ATTEMPTED_SERVICE_STOP；top_list=NOT_ATTEMPTED_SERVICE_STOP；top_inst=NOT_ATTEMPTED_SERVICE_STOP

临时排队/业务 timeout 只等待30秒再试一次；仍失败留到下一自然运行。
合格只指所收单页的日期/身份解释，不代表全市场、全部分页或经济正确；空结果不是没有行为。
完整字段、来源声明、逐行缺口及原件定位见 [补充原件解释](smart-money/relay.json)。
Relay 行为与既有 HiThink/FTShare/Eastmoney/HKEX 来源并列，不静默替代。
