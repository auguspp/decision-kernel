## D：集合竞价条件观察（shadow）

目标交易日：2026-09-30；昨日池日期：2026-09-29。
状态：SHADOW_AUCTION_READING；时点：HISTORICAL_OR_LATE_NOT_PREOPEN_DISCOVERY。
返回涨停池分母 57；静态条件内 12；竞价可比 12；原条件匹配 0。
来源截断或逐名缺口：本次返回范围未发现；不是独立穷尽认证。
固定观察条件：昨日换手10–30%、沪深主板且昨日名称不含ST、竞价相对接口昨收高开3–9%。
历史/盘后补读不是开盘前发现；昨日池、缺口及筛掉项全部保留。不修改Research/Odds，不形成买卖或唤醒。

完整返回池、逐名理由与独立来源时钟见 [details/stock/auction-probe.json](details/stock/auction-probe.json)。
