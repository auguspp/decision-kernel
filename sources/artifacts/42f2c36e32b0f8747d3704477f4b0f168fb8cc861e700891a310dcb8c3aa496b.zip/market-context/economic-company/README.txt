行业走势—产业数据—公司依据 / 只读联合页面

打开 index.html；完整行业表仍在上一级 context/index.html。
association.json、input-set.json、company-links.json 保留各自原有身份。
delivery.json 记录本次运行、输入截止、页面生成和包内文件身份。
inputs.zip 保存本次确实读取的状态副本、经济种子、完整接受包、映射及公司摘录。
它不是新的恢复来源、生产账本、完整历史数据库或原始公司 PDF 永久归档。

复现：核对实际 GitHub run、commit 和外层附件摘要，再核对 delivery.json。
将 inputs.zip 解压到独立 input-copy 目录，在精确 build_commit 的代码环境中运行：
python -m decision_kernel.runtime.economic_company_context --source-root ../input-copy \
  --seed ../input-copy/radar_inputs/economic-node-study-2026-09-05.json \
  --reviews-dir ../input-copy/radar_inputs/economic-reviewed-releases \
  --bundle ../input-copy/state \
  --parent-hints ../input-copy/radar_inputs/sector-parent-hints-2026-09-05.json \
  --links ../input-copy/radar_inputs/economic-market-links-v0.json \
  --company-links radar_inputs/economic-company-links-livestock-v1.json \
  --as-of <delivery.json 中的 input_cutoff> --output ../rebuilt-reading
新生成时间会改变 HTML／外层报告字节，但不改变固定截止下的投影。

本页没有重新采集行情、经济数据或公司 PDF。旧资料不是本日最新发布确认。
公司摘录的 PARTIAL 等级不提升；归因、业务暴露比例与净受益方向仍未建立。
生成成功不等于已上传，更不等于整次工作流、权威状态或 cache 已保存成功。
附件保留90天。过期后须有原包或另行保存的全部精确输入；哈希不能恢复缺失原文。
SHADOW OBSERVATION ONLY. Human / Research / Investment authority = NONE.
