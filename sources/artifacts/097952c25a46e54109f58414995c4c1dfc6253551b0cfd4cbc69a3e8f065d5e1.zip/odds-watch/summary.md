# Odds Watch v0

观察时间：2026-09-30T08:20:33.763018Z

**需要复核：0** · 价格缺口：0 · 活跃监控：5

## 仍在等待原边界

- **恒瑞医药 600276.SH** · CNY47.2 · 下一边界 `around CNY39.6 assumption recheck` · 距离上沿 CNY7.6
- **兴业科技 002674.SZ** · CNY19.82 · 下一边界 `CNY15–17 re-underwrite` · 距离上沿 CNY2.82
- **北大荒 600598.SH** · CNY12.63 · 下一边界 `CNY11.0–11.3 re-underwrite` · 距离上沿 CNY1.33
- **三花智控 002050.SZ** · CNY35.71 · 下一边界 `around CNY30 first-tranche condition` · 距离上沿 CNY5.71
- **兆易创新 603986.SH** · CNY353.9 · 下一边界 `around CNY350 pre-entry assumption review` · 距离上沿 CNY3.9

<details>
<summary>未启用价格触发（6）</summary>

- **光电股份 600184.SH** · `CHALLENGED_NO_ACTIVE_TRIGGER` · Valuation bridge was challenged; old ladder must not reactivate from price alone.
- **内蒙一机 600967.SH** · `EVIDENCE_REVIEW_ONLY_NO_PRICE_BOUNDARY` · Human accepted WEAK/FRAGILE Odds, but no method-ready first-entry price condition was established.
- **贵州茅台 600519.SH** · `UNTYPED_HISTORY_NO_ACTIVE_TRIGGER` · Saved Inbox history was not typed-revalidated as current Odds.
- **中国神华 601088.SH** · `UNTYPED_HISTORY_NO_ACTIVE_TRIGGER` · Saved Inbox history was not typed-revalidated as current Odds.
- **宁德时代 300750.SZ** · `DEQUALIFIED_HISTORY_ONLY` · Current decision qualification exited; historical Odds are not an active trigger.
- **招商银行 600036.SH** · `DEQUALIFIED_HISTORY_ONLY` · No current qualified watch boundary is established by the Odds backfill.

</details>

Watch hash: `d1a60d7e708aaabb5dfb68dc539b0a561c28dfd02f48407a4a8aef9b43842905`

_Price changes Odds; Evidence changes Belief. Watch allocates Human review attention only. Investment Authority = NONE._
