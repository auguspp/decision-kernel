## Sector Discovery Radar operations — `FAILED_CLOSED`

**SHADOW OBSERVATION ONLY**

`NOT RESEARCH` · `NOT A RECOMMENDATION`

`HUMAN ATTENTION AUTHORITY = NONE` · `INVESTMENT AUTHORITY = NONE`

Run: `34953967381` attempt `1`

Restore source: `LATEST_SUCCESS_ARTIFACT`

Cached completed session: `2026-09-14`

Failure: `SectorRadarAuditError`

Audited producer rejected input (HithinkRuntimeError): HiThink request or response decoding failed for /api/a-share/calendar/trading-days; failure_kind=URL_ERROR; elapsed_ms=2165

No new persistent state was published by this failed run.

Operations hash: `28485e6b502cf03f05261b9a4c7134e47ee27bc898b7056eba94b261bd248c24`

Artifacts are retained for the declared workflow retention window. There is no automatic long-term checkpoint in v0; expiration of the latest successful state artifact requires explicit qualified recovery.
