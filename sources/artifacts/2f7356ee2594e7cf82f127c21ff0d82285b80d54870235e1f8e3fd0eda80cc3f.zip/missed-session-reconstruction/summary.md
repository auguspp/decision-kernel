# 2026-09-14 板块历史重建（部分交付）

输入属性：LIVE_HITHINK。
仅重建已保存的指数输入；不是当日自然运行成功，也不是今日股票推荐。
原运行：34868170673；重建时间：2026-09-15T07:24:28.536979+00:00。
来源检查截点：2026-09-14T16:23:34.646808+00:00；不是声称这些数据在收盘瞬间已经可得。

| 板块 | 代码 | 新状态 | 5日相对基准超额 | 20日相对基准超额 |
|---|---|---|---:|---:|
| 燃气 | 881146.TI | ACCELERATING_ENTRY | +3.12pct | +9.37pct |
| 影视院线 | 881274.TI | PERSISTENT_TOP_DECILE_ENTRY | +0.32pct | +11.13pct |
| 印制电路板 | 884092.TI | ACCELERATING_ENTRY | +14.71pct | +19.75pct |
| 水电 | 884147.TI | ACCELERATING_AND_PERSISTENT_ENTRY | +9.36pct | +12.44pct |
| 焦炭加工 | 884015.TI | ACCELERATING_ENTRY | +6.78pct | +18.17pct |
| 乘用车 | 884099.TI | ACCELERATING_ENTRY | +6.73pct | +7.99pct |
| 炭黑 | 884051.TI | ACCELERATING_ENTRY | +6.25pct | +13.28pct |
| 电能综合服务 | 884246.TI | ACCELERATING_ENTRY | +6.19pct | +9.17pct |
| 地面兵装 | 884182.TI | ACCELERATING_ENTRY | +4.12pct | +11.72pct |
| 热力 | 884149.TI | ACCELERATING_ENTRY | +3.35pct | +10.34pct |
| 城商行 | 884251.TI | PERSISTENT_TOP_DECILE_ENTRY | +4.80pct | +12.56pct |
| 自然景点 | 884164.TI | PERSISTENT_TOP_DECILE_ENTRY | -0.03pct | +12.19pct |
| 农商行 | 884252.TI | PERSISTENT_TOP_DECILE_ENTRY | +4.12pct | +12.04pct |
| 农用机械 | 884078.TI | PERSISTENT_TOP_DECILE_ENTRY | -2.65pct | +11.84pct |

共 14 个状态进入项；不是 14 只股票。

股票尚未重建：原计划需要 23 份当时成员表及当时全市场股票截面，原失败包没有这些输入。
缺口不能用今日成员倒填，也不能解释成零只股票合格。此读取不写生产状态，不改旧事件账本，不发起研究、Odds或交易。
