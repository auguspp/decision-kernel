# Attention Inbox

生成时间：2026-09-16T09:29:33.929721+00:00

**需要关注：1**　·　后台研究处置：0　·　安静已研究：3

## 贵州茅台 600519

**为什么值得看**  
2026 H1营业收入同比+1.47%，归母净利润同比-1.95%，同时公司加速价格与渠道机制改革，适合重新检查当前价格对应的赔率。

**当前状态：** Research 已存在 · `ACCEPTABLE_ODDS` · ¥1258.00 · 行情 2026-09-16T15:00:00+08:00

<details>
<summary>深入查看</summary>

系统投资权限：`NONE`

**我们相信什么**  
贵州茅台的品牌与直接触达消费者的渠道能力有机会在白酒行业调整期维持较强现金经济性，但短期盈利重新加速尚未得到验证。

**市场可能在定价什么**  
工作假设：市场已经在折价反映低增长过渡、渠道租值压缩与价格机制改革的不确定性；进一步上行需要直接渠道改革稳定实际成交经济性并重新带动盈利增长。

**关键问题**
- 2026 H2归母净利润增速能否在二季度走弱后重新转正？
- 直销与i茅台占比提升能否在不牺牲销量的前提下稳定实际成交经济性？
- 系列酒在2026 H1收入承压后能否稳定？

**失效条件**
- 核心茅台酒收入连续两个报告期出现明显下降。
- 渠道与价格改革未能稳定实际成交经济性，同时利润增长持续为负。
- 后续一手披露显示社会渠道库存持续、显著累积。

**监控指标**
- 下一季度营业收入与归母净利润同比增速
- 茅台酒与系列酒收入结构
- 直销及i茅台收入占比
- 管理层对价格机制与渠道库存的最新一手披露

</details>

<details>
<summary>无需关注（3）</summary>

- **三花智控 002050** — ¥33.73 — `INSUFFICIENT_ODDS` — 重新值得看：`ACCEPTABLE_ODDS ≤ ¥29.56`
<details>
<summary>为什么安静</summary>

- 当前：期望收益 `11.3%` · 正收益概率 `60%`
- `ACCEPTABLE_ODDS` 要求：期望收益 ≥ `27%` · 正收益概率 ≥ `55%`
- 重新值得看：`ACCEPTABLE_ODDS ≤ ¥29.56`（距当前价约 `-12.4%`）
- Frozen scenarios：consensus_core 35% → ¥36.71 · core_slowdown 15% → ¥26.89 · new_business_success 20% → ¥46.48 · robot_right_tail 5% → ¥70.91 · sell_side_low_core 25% → ¥31.28

</details>
- **中国神华 601088** — ¥47.10 — `INSUFFICIENT_ODDS` — 重新值得看：`ACCEPTABLE_ODDS ≤ ¥35.37`
<details>
<summary>为什么安静</summary>

- 当前：期望收益 `-4.6%` · 正收益概率 `25%`
- `ACCEPTABLE_ODDS` 要求：期望收益 ≥ `27%` · 正收益概率 ≥ `55%`
- 重新值得看：`ACCEPTABLE_ODDS ≤ ¥35.37`（距当前价约 `-24.9%`）
- Frozen scenarios：base 50% → ¥44.80 · downside 25% → ¥31.20 · upside 25% → ¥58.90

</details>
- **兆易创新 603986** — ¥373.14 — `INSUFFICIENT_ODDS` — 重新值得看：`ACCEPTABLE_ODDS ≤ ¥330.69`
<details>
<summary>为什么安静</summary>

- 当前：期望收益 `17%` · 正收益概率 `70%`
- `ACCEPTABLE_ODDS` 要求：期望收益 ≥ `32%` · 正收益概率 ≥ `55%`
- 重新值得看：`ACCEPTABLE_ODDS ≤ ¥330.69`（距当前价约 `-11.4%`）
- Frozen scenarios：partial_normalization 20% → ¥310.08 · rapid_normalization 10% → ¥203.06 · research_high_core 30% → ¥538.65 · research_low_core 30% → ¥427.79 · right_tail 10% → ¥642.68

</details>

</details>


_Research Funnel allocates research budget; only HumanResearchSurface owns the canonical Decision wake._

_Research ≠ Recommendation · Investment Authority = NONE_
