## Sector Discovery Radar operations — `FAILED_CLOSED`

**SHADOW OBSERVATION ONLY**

`NOT RESEARCH` · `NOT A RECOMMENDATION`

`HUMAN ATTENTION AUTHORITY = NONE` · `INVESTMENT AUTHORITY = NONE`

Run: `34916726061` attempt `1`

Restore source: `LATEST_SUCCESS_ARTIFACT`

Cached completed session: `2026-09-11`

Failure: `SectorRadarAuditError`

Audited producer rejected input (HithinkIndexAdapterError): HiThink index field open_price must be positive

No new persistent state was published by this failed run.

Operations hash: `d678548b15873cc13daa9b398ee66161433976e3e31049e10a0db01a030c1db8`

Artifacts are retained for the declared workflow retention window. There is no automatic long-term checkpoint in v0; expiration of the latest successful state artifact requires explicit qualified recovery.
