## Sector Discovery Radar operations — `FAILED_CLOSED`

**SHADOW OBSERVATION ONLY**

`NOT RESEARCH` · `NOT A RECOMMENDATION`

`HUMAN ATTENTION AUTHORITY = NONE` · `INVESTMENT AUTHORITY = NONE`

Run: `37295151349` attempt `1`

Failure: `SectorRadarPersistenceError`

Sector Radar cache conflicts with the latest successful artifact

No new persistent state was published by this failed run.

Operations hash: `9dfd7d73e15489e355c8a0b1b87860b048c2a16bfd9a2686df6bd8f5e0752a76`

Artifacts are retained for the declared workflow retention window. There is no automatic long-term checkpoint in v0; expiration of the latest successful state artifact requires explicit qualified recovery.
