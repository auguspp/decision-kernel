# 全球指数 · 有限日线

这是数据观察，不是 Quick、原因解释或投资信号。
请求窗口截止：2026-10-06；实际抓取截止：2026-10-07T05:59:41.421343+00:00
来源：第三方 Tushare Relay；不等同官方源，非实时行情。市场开闭状态 UNKNOWN。

| 对象 | 原数据日期 | 数值/单位 | 上一返回日期 | 两次返回间变化 |
|---|---|---|---|---|
| SPX | UNKNOWN | REQUEST_RECEIPT_UNAVAILABLE | — | 不作无变化推断 |
| IXIC | UNKNOWN | NOT_ATTEMPTED_SERVICE_STOP | — | 不作无变化推断 |
| HSI | UNKNOWN | NOT_ATTEMPTED_SERVICE_STOP | — | 不作无变化推断 |
| HKTECH | UNKNOWN | NOT_ATTEMPTED_SERVICE_STOP | — | 不作无变化推断 |
| N225 | UNKNOWN | NOT_ATTEMPTED_SERVICE_STOP | — | 不作无变化推断 |
| GDAXI | UNKNOWN | NOT_ATTEMPTED_SERVICE_STOP | — | 不作无变化推断 |

变化只比较同系列两个实际返回日期，不保证相邻交易日；日线日期不替代发布时间或抓取时刻。
Shibor 不代表美债收益率。美债、黄金原油、外汇、加密资产及其市场日历尚未由本切片覆盖。
失败与空返回保留为缺口，不清除旧档案、不解释为没有市场变化。
