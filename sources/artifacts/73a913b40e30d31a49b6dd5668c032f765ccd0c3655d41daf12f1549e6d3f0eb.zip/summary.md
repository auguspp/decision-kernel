# 黄金与原油 · 供应商期货日线

来源观察，不是研究解释、实时交易报价或投资信号。
窗口截止：2026-10-09；抓取截止：2026-10-10T07:41:46.362578+00:00
状态：UNAVAILABLE；来源日期不替代抓取/发布时间。

| 对象 | 来源日期 | 数值 | 单位 | 上一返回日期 | 变化 |
|---|---|---|---|---|---|
| 黄金 · GC=F | UNKNOWN | UNKNOWN | USD_PER_TROY_OUNCE | UNKNOWN | UNKNOWN |
| WTI原油 · CL=F | UNKNOWN | UNKNOWN | USD_PER_BARREL | UNKNOWN | UNKNOWN |
| Brent原油 · BZ=F | UNKNOWN | UNKNOWN | USD_PER_BARREL | UNKNOWN | UNKNOWN |

变化只比较两个实际返回日期，不猜相邻交易日。失败/空值不是市场无变化。
美债为年化par yield而非债券回报；ECB为每欧元信息参考价；Coinbase仅代表该场所。
Yahoo =F 是供应商期货序列，不冒充现货/结算价；换月连续性未建立，不计算跨日收益。
原件为本次取得版本，不冒充历史当时可知；市场开闭状态和原发布时间保持UNKNOWN。

## 来源请求
- GC=F：SOURCE_TABLE_UNCONFIRMED
- CL=F：SOURCE_TABLE_UNCONFIRMED
- BZ=F：SOURCE_TABLE_UNCONFIRMED

## 日期资格（不是实际发布时间）
规则：PRIOR_UTC_DATE_ONLY_FUTURES_FINALITY_UNKNOWN；时区：UTC
原采集开始时可请求日期上限：2026-10-09
参考值机会门槛（来源当地）：不适用
到达机会时钟不证明资料已发布；只展示实际返回日期，未返回不补值。
参考利率/汇率不是全天价格线；期货终局性未知，UTC日桶未结束不得提前使用。
