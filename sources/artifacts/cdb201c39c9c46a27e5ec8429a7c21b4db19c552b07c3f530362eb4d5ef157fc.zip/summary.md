## Tushare Relay 补充来源

状态 PARTIAL_WITH_EXPLICIT_GAPS；市场日 2026-09-30；取得截止 2026-10-06T16:17:28.844709+00:00。第三方中转，不是官方Tushare或聪明钱评分。

| 接口 | 取得状态 | 解析行数 | 日期/身份合格行数 |
|---|---|---:|---:|
| hm_list | SUCCESS | 116 | 116 |
| hm_detail | SUCCESS | 279 | 279 |
| report_rc | PARTIAL_DAILY_PAGES | 18 | 18 |
| top_list | SUCCESS | 79 | 79 |
| top_inst | SUCCESS | 66 | 66 |

报告日分别取得；每行仍是报告的一个预测期，不是独立新事件。

| 报告日 | 状态 | 保存行数 |
|---|---|---:|
| 20261007 | TEMPORARY_QUEUE | 0 |
| 20261006 | TEMPORARY_QUEUE | 0 |
| 20261005 | TEMPORARY_QUEUE | 0 |
| 20261004 | TEMPORARY_QUEUE | 0 |
| 20261003 | TEMPORARY_QUEUE | 0 |
| 20261002 | SUCCESS | 15 |
| 20261001 | SUCCESS | 3 |

缺口：report_rc=TEMPORARY_QUEUE；report_rc=TEMPORARY_QUEUE；report_rc=TEMPORARY_QUEUE；report_rc=TEMPORARY_QUEUE；report_rc=TEMPORARY_QUEUE

临时排队/业务 timeout 只等待30秒再试一次；仍失败留到下一自然运行。
合格只指所收单页的日期/身份解释，不代表全市场、全部分页或经济正确；空结果不是没有行为。
完整字段、来源声明、逐行缺口及原件定位见 [补充原件解释](smart-money/relay.json)。
Relay 行为与既有 HiThink/FTShare/Eastmoney/HKEX 来源并列，不静默替代。
