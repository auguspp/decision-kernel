## Sector Discovery Radar operations — `FAILED_CLOSED`

**SHADOW OBSERVATION ONLY**

`NOT RESEARCH` · `NOT A RECOMMENDATION`

`HUMAN ATTENTION AUTHORITY = NONE` · `INVESTMENT AUTHORITY = NONE`

Run: `34489102107` attempt `1`

Restore source: `LATEST_SUCCESS_ARTIFACT`

Cached completed session: `2026-09-09`

Failure: `SectorRadarAuditError`

Audited producer rejected input (HithinkRuntimeError): HiThink request or response decoding failed for /api/a-share/calendar/trading-days

No new persistent state was published by this failed run.

Operations hash: `a748da7b25168a38a61de500a059f25ecb7de5d68ed044247eabd5a84cba2ac4`

Artifacts are retained for the declared workflow retention window. There is no automatic long-term checkpoint in v0; expiration of the latest successful state artifact requires explicit qualified recovery.
