

## D：原竞价名单的09:40分钟观察

市场日：2026-09-30；目标为09:39–09:40这一分钟的供应商收盘字段。
原名单57名，准确09:40收盘可读0名；HISTORICAL_OR_LATE_NOT_0940_DISCOVERY。
原竞价：HISTORICAL_OR_LATE_NOT_PREOPEN_DISCOVERY；分钟资料取得截止：2026-10-05T05:22:41.648111+00:00。
本次来源停止原因：ENTITLEMENT_DENIED；其后的请求未执行。
| 原分组 | 完整分母 | 09:40可读 |
|---|---:|---:|
| 原条件匹配组 | 0 | 0 |
| 竞价可比但未匹配组 | 12 | 0 |
| 静态条件内但竞价未完成组 | 0 | 0 |
| 静态条件排除组 | 45 | 0 |
| 静态条件未能判断组 | 0 | 0 |

| 证券 | 原分组 | 原竞价价 | 09:40收盘 | 状态 |
|---|---|---:|---:|---|
| 000002.SZ | 静态条件排除组 | — | — | ENTITLEMENT_DENIED |
| 000011.SZ | 静态条件排除组 | — | — | ENTITLEMENT_DENIED |
| 000036.SZ | 静态条件排除组 | — | — | ENTITLEMENT_DENIED |
| 000068.SZ | 静态条件排除组 | — | — | ENTITLEMENT_DENIED |
| 000607.SZ | 竞价可比但未匹配组 | 4.03 | — | ENTITLEMENT_DENIED |
| 000678.SZ | 静态条件排除组 | — | — | ENTITLEMENT_DENIED |
| 000823.SZ | 竞价可比但未匹配组 | 24.5 | — | ENTITLEMENT_DENIED |
| 002058.SZ | 静态条件排除组 | — | — | ENTITLEMENT_DENIED |
| 002074.SZ | 静态条件排除组 | — | — | ENTITLEMENT_DENIED |
| 002205.SZ | 竞价可比但未匹配组 | 12.44 | — | ENTITLEMENT_DENIED |
| 002242.SZ | 静态条件排除组 | — | — | ENTITLEMENT_DENIED |
| 002244.SZ | 静态条件排除组 | — | — | ENTITLEMENT_DENIED |
| 002303.SZ | 竞价可比但未匹配组 | 6.65 | — | ENTITLEMENT_DENIED |
| 002494.SZ | 竞价可比但未匹配组 | 5.24 | — | ENTITLEMENT_DENIED |
| 002799.SZ | 静态条件排除组 | — | — | ENTITLEMENT_DENIED |
| 002813.SZ | 静态条件排除组 | — | — | ENTITLEMENT_DENIED |
| 002815.SZ | 竞价可比但未匹配组 | 24.2 | — | ENTITLEMENT_DENIED |
| 002846.SZ | 静态条件排除组 | — | — | ENTITLEMENT_DENIED |
| 002866.SZ | 静态条件排除组 | — | — | ENTITLEMENT_DENIED |
| 002882.SZ | 静态条件排除组 | — | — | ENTITLEMENT_DENIED |
| 002912.SZ | 竞价可比但未匹配组 | 28.57 | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 002913.SZ | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 301190.SZ | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 301513.SZ | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 301560.SZ | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 600032.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 600152.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 600189.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 600241.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 600325.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 600488.SH | 竞价可比但未匹配组 | 6.85 | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 600657.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 600825.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 600982.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 601238.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 601519.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 601811.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 601949.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 603188.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 603200.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 603322.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 603328.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 603533.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 603598.SH | 竞价可比但未匹配组 | 19.1 | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 603602.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 603630.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 603636.SH | 竞价可比但未匹配组 | 8.08 | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 603949.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 603980.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 605058.SH | 竞价可比但未匹配组 | 59.6 | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 605198.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 605258.SH | 竞价可比但未匹配组 | 43.17 | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 605303.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 605388.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 688655.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 688685.SH | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
| 920779.BJ | 静态条件排除组 | — | — | NOT_REQUESTED_AFTER_SOURCE_STOP |
后补历史分钟不是当时发现；没有最近值填补、跨来源收益、买卖点或概率。缺量额/其他分钟不取消准确时点的收盘。
完整名单、每项缺口、原始请求与取得时间见 [details/stock/auction-minutes.json](details/stock/auction-minutes.json)。
